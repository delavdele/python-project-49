# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0', 'random2>=1.0.1,<2.0.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.5',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/delavdele/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/delavdele/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/5295f02a1a0db29e1349/maintainability)](https://codeclimate.com/github/delavdele/python-project-49/maintainability)\n\n[![asciicast](https://asciinema.org/a/v2AFHg9peLM3SMWXYdoVot7NO.svg)](https://asciinema.org/a/v2AFHg9peLM3SMWXYdoVot7NO)\n\n[![asciicast](https://asciinema.org/a/YyBHGp9elV9gRRdnAWKUYMnXx.svg)](https://asciinema.org/a/YyBHGp9elV9gRRdnAWKUYMnXx)\n',
    'author': 'Adel Yudina',
    'author_email': 'adelyudina@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
