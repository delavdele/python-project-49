#!/usr/bin/env python3

from cli.py import welcome_user

def main():
 	print('Welcome to the Brain Games!')
        print('Hello, ' + name)

if __name__=='__main__':
	main()
