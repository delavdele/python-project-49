### Hexlet tests and linter status:
[![Actions Status](https://github.com/delavdele/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/delavdele/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/5295f02a1a0db29e1349/maintainability)](https://codeclimate.com/github/delavdele/python-project-49/maintainability)
